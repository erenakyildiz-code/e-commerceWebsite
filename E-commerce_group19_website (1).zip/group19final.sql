-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2021 at 12:52 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group19final`
--

-- --------------------------------------------------------

--
-- Table structure for table `added_to`
--

CREATE TABLE `added_to` (
  `bid` int(10) NOT NULL,
  `pid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `added_to`
--

INSERT INTO `added_to` (`bid`, `pid`) VALUES
(1, 1),
(1, 2),
(1, 4),
(1, 5),
(2, 1),
(2, 3),
(3, 6),
(3, 7),
(4, 5),
(5, 1),
(6, 9),
(12, 12),
(13, 13),
(14, 14),
(15, 15),
(16, 16);

-- --------------------------------------------------------

--
-- Table structure for table `basket`
--

CREATE TABLE `basket` (
  `bid` int(10) NOT NULL,
  `total_price` double DEFAULT NULL,
  `pid_list` char(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `basket`
--

INSERT INTO `basket` (`bid`, `total_price`, `pid_list`) VALUES
(1, 80, '1,2'),
(2, 140, '1,3'),
(3, 200, '3,4'),
(4, 60, '6,10,11'),
(5, 230, '4,15'),
(6, 280, '1,2,3,4'),
(7, 500, '7'),
(8, 520, '1,7'),
(9, 40, '10,11'),
(10, 380, '12,13'),
(11, 650, '5,14'),
(12, 95, '1,8'),
(13, 360, '13,16'),
(14, 220, '1,3,4'),
(15, 40, '10,11'),
(16, 250, '14'),
(17, 1020, '3, 5, 10, 11, 14, 15'),
(18, 980, '3, 5, 11, 14, 15'),
(19, 400, '5'),
(20, 400, '5'),
(21, 545, '5,3,11'),
(22, 640, '4,5,16'),
(23, 400, '5'),
(24, 400, '5'),
(25, 400, '5'),
(26, 400, '5'),
(27, 400, '5'),
(28, 400, '5'),
(29, 400, '5'),
(30, 400, '5'),
(31, 1320, '5,3,5,5'),
(32, 920, '5,3,5'),
(33, 400, '5'),
(34, 420, '5,1'),
(35, 400, '5'),
(36, 580, '5,1,16'),
(37, 420, '1,5'),
(38, 3200, '5,5,5,5,5,5,5,5'),
(39, 800, '5,5'),
(40, 400, '5'),
(41, 400, '5'),
(42, 400, '5'),
(43, 400, '5'),
(44, 400, '5'),
(45, 400, '5'),
(46, 400, '5'),
(47, 400, '5'),
(48, 400, '5'),
(49, 160, '16'),
(50, 160, '16'),
(51, 400, '5'),
(52, 520, '3,5,16'),
(53, 400, '5'),
(54, 400, '5'),
(55, 0, ''),
(56, 330, '16,3,11,11'),
(57, 175, '11,11,11,11,11,11,11'),
(58, 120, '3'),
(59, 160, '16'),
(60, 80, '17,17,17,17'),
(61, 400, '5'),
(62, 880, '5,16,16,16'),
(63, 160, '16'),
(64, 160, '16'),
(65, 160, '16'),
(66, 320, '16,16'),
(67, 560, '5,16'),
(68, 160, '16'),
(69, 160, '16'),
(70, 400, '5'),
(71, 160, '16'),
(72, 160, '16'),
(73, 400, '5'),
(74, 160, '16'),
(75, 0, ''),
(76, 400, '5'),
(77, 15, '10'),
(78, 190, '16,10,10'),
(79, 175, '10,16'),
(80, 160, '16'),
(81, 160, '16'),
(82, 160, '16'),
(83, 400, '5'),
(84, 560, '16,5'),
(85, 160, '16'),
(86, 160, '16'),
(87, 400, '5'),
(88, 25, '11'),
(89, 80, '4'),
(90, 400, '5'),
(91, 160, '16'),
(92, 400, '5'),
(93, 400, '5'),
(94, 400, '5'),
(95, 400, '5'),
(96, 400, '5'),
(97, 400, '5'),
(98, 400, '5'),
(99, 160, '16'),
(100, 15, '10'),
(101, 160, '16'),
(102, 160, '16'),
(103, 160, '16'),
(104, 160, '16'),
(105, 400, '5'),
(106, 400, '5'),
(107, 560, '5,16'),
(108, 80, '4'),
(109, 160, '16'),
(110, 400, '5'),
(111, 160, '16'),
(112, 400, '5'),
(113, 400, '5'),
(114, 735, '16,7,8'),
(115, 400, '5'),
(116, 160, '16'),
(117, 80, '4'),
(118, 60, '2'),
(119, 120, '3'),
(120, 400, '5'),
(121, 400, '5'),
(122, 800, '5,5'),
(123, 1600, '5,5,5,5'),
(124, 560, '5,16'),
(125, 400, '5'),
(126, 400, '5'),
(127, 20, '1'),
(128, 140, '3,1'),
(129, 1280, '16,16,16,5,5'),
(130, 800, '5,5'),
(131, 400, '5'),
(132, 400, '5'),
(133, 400, '5'),
(134, 560, '5,16'),
(135, 400, '5'),
(136, 400, '5'),
(137, 400, '5'),
(138, 400, '5'),
(139, 400, '5'),
(140, 560, '5,16'),
(141, 560, '16,5'),
(142, 400, '5'),
(143, 400, '5'),
(144, 400, '5'),
(145, 0, ''),
(146, 320, '16,16'),
(147, 240, '1,1,1,1,16'),
(148, 400, '5'),
(149, 1200, '5,5,5'),
(150, 0, ''),
(151, 560, '5,16'),
(152, 75, '11,11,11'),
(153, 400, '5'),
(154, 310, '16,15'),
(155, 400, '5'),
(156, 400, '5'),
(157, 400, '5'),
(158, 400, '5'),
(159, 160, '16'),
(160, 0, ''),
(161, 0, ''),
(162, 0, ''),
(163, 0, ''),
(164, 400, '5'),
(165, 0, ''),
(166, 0, ''),
(167, 0, ''),
(168, 230, '13,1'),
(169, 150, '15'),
(170, 580, '12,5');

-- --------------------------------------------------------

--
-- Table structure for table `billing_info`
--

CREATE TABLE `billing_info` (
  `seller_address` char(70) DEFAULT NULL,
  `seller_contact_info` char(50) DEFAULT NULL,
  `seller_payment_info` char(50) DEFAULT NULL,
  `card_id` bigint(16) DEFAULT NULL,
  `oid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `billing_info`
--

INSERT INTO `billing_info` (`seller_address`, `seller_contact_info`, `seller_payment_info`, `card_id`, `oid`) VALUES
('Atasehir/ Istanbul', '05385410938', 'INVOICE COMES HERE', 1029384105620349, 1),
('Atasehir/ Istanbul', '05375410178', 'INVOICE COMES HERE', 1234517821918191, 2),
('Esenyurt/ Istanbul', '05345099090', 'INVOICE COMES HERE', 3249812693812691, 3),
('Kadikoy/ Istanbul', '05345091324', 'INVOICE COMES HERE', 2938947989189171, 4),
('Acibadem/ Istanbul', '05425420487', 'INVOICE COMES HERE', 1247726726617214, 5),
('Acibadem/ Istanbul', '05455467826', 'INVOICE COMES HERE', 1192868728172515, 6),
('Kizilay/ Ankara', '05355903242', 'INVOICE COMES HERE', 1005296061023957, 7),
('Acibadem/ Istanbul', '05395092341', 'INVOICE COMES HERE', 1247986826176231, 8),
('Besiktas / Istanbul', '05385192030', 'INVOICE COMES HERE', 4205120346931091, 9),
('Bati Atasehir/ Istanbul', '05364538798', 'INVOICE COMES HERE', 1013284105623425, 10),
('Maltepe / Istanbul', '02163395015', 'INVOICE COMES HERE', 4229384105192746, 11),
('Kozyatagi /Istanbul', '05325436426', 'INVOICE COMES HERE', 1093719276817281, 12);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `cid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `date` date NOT NULL,
  `text` char(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`cid`, `pid`, `uid`, `date`, `text`) VALUES
(1, 5, 1005, '2020-02-03', 'HARIKA'),
(2, 5, 1005, '2019-03-10', 'hic begenmedik, cok uzucu'),
(3, 5, 1008, '2020-04-21', 'surekli aliyorum cok begeniyorum'),
(4, 5, 1007, '2019-08-13', 'urun guzel paketlenmis'),
(5, 8, 1007, '2020-04-23', 'i didnt like the smell of the product'),
(6, 4, 1007, '2019-04-12', 'ball'),
(7, 15, 1011, '2020-01-30', 'havasi cabuk kaciyor ama guzel renkli'),
(8, 14, 1013, '2019-02-15', 'ses kalitesi cok iyi'),
(9, 13, 1014, '2020-01-13', 'cakma cikti'),
(10, 12, 1016, '2019-02-10', 'kizlari tavlamak icin mukemmel bir koku ;)'),
(11, 10, 1008, '2020-03-19', 'hacisakir kadar iyi degil'),
(12, 3, 1015, '2019-01-13', 'nice clothing'),
(13, 7, 1017, '2020-10-01', 'cok rahat'),
(14, 7, 1018, '2019-05-08', 'ben begenmedim, rengi bekledigim gibi gelmedi'),
(15, 16, 1005, '2021-01-10', 'Very nice sunscreen.'),
(16, 16, 1005, '2021-01-10', 'Also very good price!'),
(17, 11, 1005, '2021-01-10', 'pls'),
(18, 11, 1005, '2021-01-10', 'This product didnt have any rating before i rated it!'),
(19, 5, 1011, '2021-01-13', 'Thank you.'),
(20, 1, 1011, '2021-01-13', 'nice sock'),
(21, 11, 1021, '2021-01-19', 'harika'),
(22, 1, 1011, '2021-01-20', 'Comy socks!'),
(23, 15, 1011, '2021-01-24', 'cok iyi reyiz');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `uid` int(10) NOT NULL,
  `card_id` bigint(16) DEFAULT NULL,
  `bid` int(10) DEFAULT NULL,
  `oid_list` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`uid`, `card_id`, `bid`, `oid_list`) VALUES
(1005, 1029384105620349, 1, '45,46'),
(1007, 1048265018491038, 2, NULL),
(1008, 8194710517294910, 3, NULL),
(1010, 8616950197868193, 4, NULL),
(1011, 4810386761988658, 5, '48,49,50,51,52,56,60'),
(1012, 1847478191919021, 6, NULL),
(1013, 4913774919102938, 7, NULL),
(1014, 4818979868175812, 8, NULL),
(1015, 5301029305125124, 9, NULL),
(1016, 5871717399918891, 10, NULL),
(1017, 6548923595358412, 17, NULL),
(1018, 7845124796321547, 18, NULL),
(1019, 3159874612659874, NULL, NULL),
(1020, 7777777777777777, NULL, NULL),
(1021, 3159874612659874, NULL, '58,59'),
(1022, 3159874612659874, NULL, NULL),
(1023, 3159874612659874, NULL, NULL),
(1024, 8745966687445478, NULL, '62');

-- --------------------------------------------------------

--
-- Table structure for table `log_users`
--

CREATE TABLE `log_users` (
  `uid` int(10) DEFAULT NULL,
  `Logid` int(10) NOT NULL,
  `username` char(20) DEFAULT NULL,
  `password_` char(20) DEFAULT NULL,
  `address` char(70) DEFAULT NULL,
  `phone_num` bigint(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_users`
--

INSERT INTO `log_users` (`uid`, `Logid`, `username`, `password_`, `address`, `phone_num`) VALUES
(1001, 1, 'Erenakyildiz', 'eren_134', 'istanbul tuzla aydinli mahallesi', 5375410178);

-- --------------------------------------------------------

--
-- Table structure for table `manage_order`
--

CREATE TABLE `manage_order` (
  `uid` int(10) NOT NULL,
  `oid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manage_order`
--

INSERT INTO `manage_order` (`uid`, `oid`) VALUES
(1001, 1),
(1001, 2),
(1001, 9),
(1002, 3),
(1002, 4),
(1002, 10),
(1003, 5),
(1003, 6),
(1004, 7),
(1004, 8);

-- --------------------------------------------------------

--
-- Table structure for table `manage_product`
--

CREATE TABLE `manage_product` (
  `uid` int(10) NOT NULL,
  `pid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manage_product`
--

INSERT INTO `manage_product` (`uid`, `pid`) VALUES
(1006, 1),
(1006, 3),
(1006, 5),
(1006, 7),
(1006, 9),
(1006, 11),
(1006, 13),
(1006, 15),
(1009, 2),
(1009, 4),
(1009, 6),
(1009, 8),
(1009, 10),
(1009, 12),
(1009, 14),
(1009, 16);

-- --------------------------------------------------------

--
-- Table structure for table `order_`
--

CREATE TABLE `order_` (
  `oid` int(10) NOT NULL,
  `invoice` char(30) NOT NULL,
  `status` char(15) DEFAULT NULL,
  `expiration_time` date NOT NULL,
  `cargo_address` char(70) DEFAULT NULL,
  `deposit_amount` char(10) DEFAULT NULL,
  `bid` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_`
--

INSERT INTO `order_` (`oid`, `invoice`, `status`, `expiration_time`, `cargo_address`, `deposit_amount`, `bid`) VALUES
(1, 'invoice.jpg', 'Deposit Paid', '0000-00-00', 'Atasehir/ Istanbul', '16', 1),
(2, 'invoice.jpg', 'Delivered', '0000-00-00', 'Bati Atasehir/ Istanbul', '0', 2),
(3, 'invoice.jpg', 'Preparing', '0000-00-00', 'Beykoz/ Istanbul', '0', 3),
(4, 'invoice.jpg', 'Preparing', '0000-00-00', 'Avcilar/ Istanbul', '0', 4),
(5, 'invoice.jpg', 'Delivered', '0000-00-00', 'Dogu Atasehir/ Istanbul', '0', 5),
(6, 'invoice.jpg', 'Deposit Paid', '0000-00-00', 'Esenyurt/ Istanbul', '56', 6),
(7, 'invoice.jpg', 'Delivered', '0000-00-00', 'Kosuyolu/ Istanbul', '0', 7),
(8, 'invoice.jpg', 'Shipped', '0000-00-00', 'Acibadem/ Istanbul', '0', 8),
(9, 'invoice.jpg', 'Refunded', '0000-00-00', 'Cekmekoy/ Istanbul', '0', 9),
(10, 'invoice.jpg', 'Expired', '0000-00-00', 'Dogu Atasehir/ Istanbul', '76', 10),
(11, 'invoice.jpg', 'Delivered', '0000-00-00', 'Kozyatagi/ Istanbul', '0', 11),
(12, 'invoice.jpg', 'Shipped', '0000-00-00', 'Kucukyali/ Istanbul', '0', 12),
(13, 'invoice.jpg', 'Preparing', '0000-00-00', 'Tuzla/ Istanbul', '0', 13),
(14, 'invoice.jpg', 'Delivered', '0000-00-00', 'Sisli/ Istanbul', '44', 14),
(15, 'invoice.jpg', 'Refunded', '0000-00-00', 'Bati Atasehir/ Istanbul', '0', 15),
(16, 'invoice.jpg', 'Expired', '0000-00-00', 'Dogu Atasehir/ Istanbul', '50', 16),
(17, 'invoice.jpg', 'Shipped', '0000-00-00', 'Besiktas/ Istanbul', '0', 17),
(18, 'invoice.jpg', 'Preparing', '0000-00-00', 'Besiktas/ Istanbul', '0', 18),
(19, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 79),
(20, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 80),
(21, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 81),
(22, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 82),
(23, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 83),
(24, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 84),
(25, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 85),
(26, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 86),
(27, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 87),
(28, 'invoice.jpg', 'Preparing', '2021-01-12', 'istanbul sariyer', '10', 89),
(29, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul kadikoy cennet mahallesi', '0', 90),
(30, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '10', 91),
(31, 'invoice.jpg', 'Preparing', '2021-01-12', 'istanbul sariyer', '10', 92),
(32, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '10', 93),
(33, 'invoice.jpg', 'Preparing', '2021-01-12', 'istanbul sariyer', '10', 94),
(34, 'invoice.jpg', 'Preparing', '2021-01-12', 'istanbul sariyer', '10', 95),
(35, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '10', 96),
(36, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '10', 97),
(37, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '10', 98),
(38, 'invoice.jpg', 'Preparing', '2021-02-12', 'istanbul sariyer', '10', 99),
(39, 'invoice.jpg', 'Preparing', '2021-02-12', 'istanbul sariyer', '3', 101),
(40, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 103),
(41, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 106),
(42, 'invoice.jpg', 'Preparing', '2021-02-12', 'istanbul sariyer', '10', 107),
(43, 'invoice.jpg', 'Preparing', '2021-02-12', 'istanbul sariyer', '40', 108),
(44, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul kadikoy cennet mahallesi', '0', 109),
(45, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 112),
(46, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul sariyer', '0', 113),
(48, 'invoice.jpg', 'dsad', '2021-02-12', 'istanbul bagcilar', '150', 115),
(49, 'invoice.jpg', 'Shipped', '2021-02-12', 'istanbul bagcilar', '50', 116),
(50, 'invoice.jpg', 'Preparing', '2021-02-12', 'istanbul bagcilar', '10', 117),
(51, 'invoice.jpg', 'Cancelled', '0000-00-00', 'istanbul bagcilar', '0', 124),
(52, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul bagcilar', '0', 127),
(53, 'invoice.jpg', 'Preparing', '0000-00-00', 'Kozyatagi', '0', 129),
(54, 'invoice.jpg', 'Preparing', '0000-00-00', 'Kozyatagi', '0', 142),
(55, 'invoice.jpg', 'Preparing', '0000-00-00', 'Kozyatagi', '0', 146),
(56, 'invoice.jpg', 'Preparing', '2021-02-13', 'istanbul bagcilar', '10', 147),
(57, 'invoice.jpg', 'Preparing', '0000-00-00', 'Kozyatagi', '0', 151),
(58, 'invoice.jpg', 'Preparing', '2021-02-19', 'Kozyatagi', '150', 153),
(59, 'invoice.jpg', 'Preparing', '0000-00-00', 'Kozyatagi', '0', 154),
(60, 'invoice.jpg', 'Preparing', '0000-00-00', 'istanbul bagcilar', '0', 158),
(61, 'invoice.jpg', 'Preparing', '0000-00-00', 'Kozyatagi', '0', 168),
(62, 'invoice.jpg', 'Preparing', '0000-00-00', 'Rusya', '0', 170);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(10) NOT NULL,
  `name` char(25) NOT NULL,
  `price` double NOT NULL,
  `overall_rating` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `name`, `price`, `overall_rating`) VALUES
(1, 'Sport Socks', 30, 6.5),
(2, 'Sport Gloves', 60, 5),
(3, 'Soccer Jersey', 120, 7),
(4, 'Soccer Ball', 80, 2),
(5, 'Wireless Keyboard', 400, 6.6667),
(6, 'Tooth Brush', 20, 8),
(7, 'Basketball Sneakers', 500, 4),
(8, 'Tennis Racket', 75, 1),
(9, 'Natural Herb Shampoo', 30, 10),
(10, 'Soap', 15, 3),
(11, 'Lip Gloss', 25, 7),
(12, 'Men Perfume', 180, 2),
(13, 'Women Perfume', 200, 9),
(14, 'Wireless Headphone', 250, 9),
(15, 'Basketball Ball', 150, 9),
(16, 'Sun Screen', 160, 4),
(17, 'Wet Wipes', 6, NULL),
(18, 'Shampoo', 15, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_manager`
--

CREATE TABLE `product_manager` (
  `uid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_manager`
--

INSERT INTO `product_manager` (`uid`) VALUES
(1006),
(1009);

-- --------------------------------------------------------

--
-- Table structure for table `rate`
--

CREATE TABLE `rate` (
  `uid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  `date` date NOT NULL,
  `rating` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rate`
--

INSERT INTO `rate` (`uid`, `pid`, `date`, `rating`) VALUES
(1005, 1, '2019-10-11', 6),
(1005, 5, '2020-10-14', 7),
(1005, 11, '2021-01-10', 5),
(1007, 2, '2020-11-03', 5),
(1008, 3, '2019-01-09', 7),
(1008, 5, '2021-01-10', 8),
(1010, 4, '2020-01-01', 2),
(1010, 15, '2020-12-12', 9),
(1010, 16, '2020-12-13', 4),
(1011, 1, '2021-01-13', 7),
(1011, 5, '2019-02-04', 5),
(1012, 7, '2019-03-03', 4),
(1013, 6, '2020-04-15', 8),
(1014, 8, '2020-05-10', 1),
(1015, 10, '2019-03-18', 3),
(1015, 12, '2020-10-11', 2),
(1015, 13, '2020-10-29', 9),
(1015, 14, '2019-02-27', 9),
(1016, 9, '2020-04-09', 10),
(1021, 11, '2021-01-19', 9);

-- --------------------------------------------------------

--
-- Table structure for table `sales_manager`
--

CREATE TABLE `sales_manager` (
  `uid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_manager`
--

INSERT INTO `sales_manager` (`uid`) VALUES
(1001),
(1002),
(1003),
(1004);

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE `search` (
  `uid` int(10) NOT NULL,
  `pid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `search`
--

INSERT INTO `search` (`uid`, `pid`) VALUES
(1005, 1),
(1005, 2),
(1005, 3),
(1005, 4),
(1005, 5),
(1005, 6),
(1005, 7),
(1005, 8),
(1005, 9),
(1005, 10),
(1005, 11),
(1005, 12),
(1005, 13),
(1005, 14),
(1005, 15),
(1005, 16),
(1007, 2),
(1007, 5),
(1008, 4),
(1010, 3),
(1011, 1),
(1011, 2),
(1011, 4),
(1011, 7),
(1011, 8),
(1011, 15),
(1012, 10),
(1013, 9),
(1014, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_`
--

CREATE TABLE `user_` (
  `uid` int(10) NOT NULL,
  `username` char(20) DEFAULT NULL,
  `password_` char(20) DEFAULT NULL,
  `address` char(70) DEFAULT NULL,
  `phone_num` bigint(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_`
--

INSERT INTO `user_` (`uid`, `username`, `password_`, `address`, `phone_num`) VALUES
(1001, 'Erenakyildiz', 'babancikkkk', 'hicbiryer', 5649821535),
(1002, 'Hakanbuyuktopcu', 'Hakbutop345', 'istanbul kadikoy kozyatagi mahallesi', 5313519808),
(1003, 'melisdogan', 'melo420', 'istanbul kadikoy kosuyolu mahallesi', 5325503940),
(1004, 'sencereyiz', 'sencor_reyizman', 'istanbul kadikoy moda mahallesi', 5532640994),
(1005, 'shoppinghunter123', 'shopshop64', 'istanbul sariyer', 5313519808),
(1006, 'pursemaster', 'ilovepurses13', 'istanbul tuzla yenibirlik osb mahallesi', 5335103068),
(1007, 'john doe', 'mypasswordiseasy', 'istanbul tuzla esenyali mahallesi', 5389819302),
(1008, 'Angarali06', 'angaram', 'ankara kizilay cincin mahallesi', 5320660606),
(1009, 'Mehmet ustundag', ' canimkizim', 'istanbul bagcilar', 5423245353),
(1010, 'babyoda', 'starwars1900', 'istanbul kadikoy', 5365410294),
(1011, 'iloveobama98', 'blacklivesmatter36', 'istanbul bagcilar', 5365410295),
(1012, 'john mayer', '1l45k1', 'istanbul kadikoy limon mahallesi', 5334235454),
(1013, 'karl', 'lovelife32', 'istanbul kadikoy tarim mahallesi', 5374110403),
(1014, 'kepler35', 'keplerisgreat99', 'istanbul besiktas kartopu mahallesi', 5435466578),
(1015, 'kircan54', 'password', 'istanbul yenikoy kale mahallesi', 5341532343),
(1016, 'usernamelol', 'Sqz123', 'istanbul yenikoy sari mahallesi', 5315350930),
(1017, NULL, NULL, NULL, NULL),
(1018, NULL, NULL, NULL, NULL),
(1019, 'MyDummyUser', 'hellohello99', 'Kozyatagi', 5313519808),
(1020, 'patatesadam', 'patateskizartmasi123', 'Rusya', 5325436726),
(1021, 'ECE', 'hakankakak', 'Kozyatagi', 5313519808),
(1022, 'dummyuser2', 'hahahahohoho', 'Kozyatagi', 5313519808),
(1023, 'ilovetheshopping99', 'mypassword123', 'Kozyatagi', 5313519807),
(1024, 'tarikkurt', 'ilovegizem3169', 'Rusya', 5698885566);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `added_to`
--
ALTER TABLE `added_to`
  ADD PRIMARY KEY (`bid`,`pid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `billing_info`
--
ALTER TABLE `billing_info`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`cid`,`pid`,`uid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `log_users`
--
ALTER TABLE `log_users`
  ADD PRIMARY KEY (`Logid`);

--
-- Indexes for table `manage_order`
--
ALTER TABLE `manage_order`
  ADD PRIMARY KEY (`uid`,`oid`),
  ADD KEY `oid` (`oid`);

--
-- Indexes for table `manage_product`
--
ALTER TABLE `manage_product`
  ADD PRIMARY KEY (`uid`,`pid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `order_`
--
ALTER TABLE `order_`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `bid` (`bid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `product_manager`
--
ALTER TABLE `product_manager`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `rate`
--
ALTER TABLE `rate`
  ADD PRIMARY KEY (`uid`,`pid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `sales_manager`
--
ALTER TABLE `sales_manager`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `search`
--
ALTER TABLE `search`
  ADD PRIMARY KEY (`uid`,`pid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `user_`
--
ALTER TABLE `user_`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `log_users`
--
ALTER TABLE `log_users`
  MODIFY `Logid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `added_to`
--
ALTER TABLE `added_to`
  ADD CONSTRAINT `added_to_ibfk_1` FOREIGN KEY (`bid`) REFERENCES `basket` (`bid`),
  ADD CONSTRAINT `added_to_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`);

--
-- Constraints for table `billing_info`
--
ALTER TABLE `billing_info`
  ADD CONSTRAINT `billing_info_ibfk_1` FOREIGN KEY (`oid`) REFERENCES `order_` (`oid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `customer` (`uid`);

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user_` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `customer_ibfk_2` FOREIGN KEY (`bid`) REFERENCES `basket` (`bid`) ON UPDATE CASCADE;

--
-- Constraints for table `manage_order`
--
ALTER TABLE `manage_order`
  ADD CONSTRAINT `manage_order_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `sales_manager` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `manage_order_ibfk_2` FOREIGN KEY (`oid`) REFERENCES `order_` (`oid`) ON DELETE CASCADE;

--
-- Constraints for table `manage_product`
--
ALTER TABLE `manage_product`
  ADD CONSTRAINT `manage_product_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `product_manager` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `manage_product_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`) ON DELETE CASCADE;

--
-- Constraints for table `order_`
--
ALTER TABLE `order_`
  ADD CONSTRAINT `order__ibfk_1` FOREIGN KEY (`bid`) REFERENCES `basket` (`bid`) ON UPDATE CASCADE;

--
-- Constraints for table `product_manager`
--
ALTER TABLE `product_manager`
  ADD CONSTRAINT `product_manager_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user_` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rate`
--
ALTER TABLE `rate`
  ADD CONSTRAINT `rate_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `customer` (`uid`),
  ADD CONSTRAINT `rate_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`);

--
-- Constraints for table `sales_manager`
--
ALTER TABLE `sales_manager`
  ADD CONSTRAINT `sales_manager_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user_` (`uid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `search`
--
ALTER TABLE `search`
  ADD CONSTRAINT `search_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `customer` (`uid`),
  ADD CONSTRAINT `search_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
