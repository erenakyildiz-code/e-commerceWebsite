<?php 
include "mainpage.php";

if(isset($_SESSION['userconfirmed'])){
	echo "Succesfully created account."."<br>";
	unset($_SESSION['userconfirmed']);
}
?>


