<?php

session_start();

include "joindatabase.php";

$last_cid;
$sql_query_cid = "SELECT * FROM comment";
$result_cid = mysqli_query($db, $sql_query_cid);
while ($row = mysqli_fetch_assoc($result_cid)){
	$last_cid = $row['cid'];
}

$comment = $_POST['newcomment'];
$new_cid = $last_cid + 1;
$cur_pid = $_SESSION['pid'];
$cur_uid = $_SESSION['uid'];
$date = "dummydate";

$date = date('Y-m-d', time());

$sql_insertcomment = "INSERT INTO comment (cid, pid, uid, date, text) VALUES ('$new_cid' ,  '$cur_pid' , '$cur_uid' ,'$date', '$comment')";
$result_com = mysqli_query($db,$sql_insertcomment);

header("Location: productpage.php");

?>