<?php 
session_start();
include "joindatabase.php";

if ( isset ($_POST['name'])){
	$uid = 0;
	$isfound = false;
	$username = $_POST['name'];
	$password = $_POST['pass'];

	if(strlen($password) < 8){
		
		$_SESSION['passwordwrong'] = 1;
	}
	if(strlen($username) < 3){
		$_SESSION['usernameshort'] = 1;

	}
	$adress = $_POST['Address'];
	if(strlen($adress) == 0){
		
		$_SESSION['addresswrong'] = 1;


	}
	$cardid = $_POST['Card_id'];
	if(strlen($cardid) != 16){
		
		$_SESSION['cardwrong'] = 1;

	}
	else{
		$myString = $cardid;
		$myArray = str_split($myString);
		$numCheck = true;
 
		foreach($myArray as $character){
    		if ( !("0" <= $character && "9" >= $character)){
        		$numCheck = false;
    		}
		}
	
		if ($numCheck == false)
		{
			
			$_SESSION['cardwrong'] = 1;
		}
	}
	$phone_num = $_POST['Phone_num'];
	if(strlen($phone_num) != 11){
		
		$_SESSION['phonewrong'] = 1;

	}
	else{
		$myString = $phone_num;
		$myArray = str_split($myString);
		$numCheck = true;
 
		foreach($myArray as $character){
    		if ( !("0" <= $character && "9" >= $character)){
        		$numCheck = false;
    		}
		}
	
		if ($numCheck == false)
		{
			
			$_SESSION['phonewrong'] = 1;
		}
	}



	$sql_query = "SELECT username, uid FROM user_ ";
	$result = mysqli_query($db, $sql_query);
	while($row = mysqli_fetch_assoc($result)){
		if($row['username'] == $username){
			$isfound = true;
			$_SESSION['usernameexists'] = 1;
			
		}
		$uid = $row['uid'];
	}
	$uid = $uid + 1;

	if(($isfound == true) || isset($_SESSION['passwordwrong']) || isset($_SESSION['addresswrong']) ||isset($_SESSION['cardwrong']) || isset($_SESSION['usernameexists']) ||isset($_SESSION['phonewrong']) || isset($_SESSION['usernameshort'])){
		header("Location: register.php");

		
	}
	else{
		$_SESSION["uid"] = $uid;
		$sql_insertquery = "INSERT INTO user_ VALUES ('$uid' , '$username', '$password', '$adress' , '$phone_num')";
		$sql_insertquery2 = "INSERT INTO customer(uid, card_id) VALUES ('$uid' ,  '$cardid')";
		$result = mysqli_query($db,$sql_insertquery);
		$result = mysqli_query($db,$sql_insertquery2);
		$_SESSION["userconfirmed"] = 1;
		$_SESSION['role'] = "cust";

		header("Location: customermain.php");

	}

}

?>