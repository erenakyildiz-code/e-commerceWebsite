<?php
session_start();
if (isset ($_SESSION['searchstyle']))
{
	if ($_SESSION['searchstyle'] == 2)
	{
		$_SESSION['searchstyle'] = 5;
	}
	else
	{
		$_SESSION['searchstyle'] = 2;
	}
}
else
{
	$_SESSION['searchstyle'] = 2;
}
header("Location: searchproducts.php")

?>