<?php

include "joindatabase.php";

session_start();

$delpid = $_SESSION['delpid'];

$newpname = $_POST['newpname'];
$newprice = $_POST['newprice'];

if ($newpname == "Delete" && $newprice == "Delete")
{
	$sql_delproduct32 = "DELETE FROM rate WHERE pid = '$delpid'";
	$result_delproduct32 = mysqli_query($db, $sql_delproduct32);
	
	$sql_delproduct3 = "DELETE FROM product WHERE pid = '$delpid'";
	$result_delproduct3 = mysqli_query($db, $sql_delproduct3);
	$_SESSION['productdeleted'] = 1;
	header("Location: product.php");
}
else if (strlen($newpname) == 0 && strlen($newprice) == 0)
{
	$_SESSION['productnochange'] = 1;
	header("Location: productmanage.php");
}
else
{
	if ((strlen($newpname) > 0) && (strlen($newpname) < 6))
	{
		$_SESSION['pnamewrong'] = 1;
	}
	if (strlen($newprice) > 0)
	{
		$myString2 = $newprice;
		$myArray2 = str_split($myString2);
		$pnamecheck = true;
 
		foreach($myArray2 as $character)
		{
    		if ( !("0" <= $character && "9" >= $character))
    		{
        		$pnamecheck = false;
    		}
		}
		if ($pnamecheck == false)
		{
			$_SESSION['pricewrong'] = 1;
		}
	}

	if (isset($_SESSION['pnamewrong']) || isset($_SESSION['pricewrong']))
	{
		header("Location: productmanage.php");
	}
	else
	{
		echo $delpid;
		if (strlen($newpname) != 0)
		{
			$sql_changepname = "UPDATE product SET name = '$newpname' WHERE pid = '$delpid'";
			$result_changepname = mysqli_query($db,$sql_changepname);
		}
		if (strlen($newprice) != 0)
		{
			$sql_changeprice = "UPDATE product SET price = '$newprice' WHERE pid = '$delpid'";
			$result_changeprice = mysqli_query($db,$sql_changeprice);
		}
		
		$_SESSION['pchanged'] = 1;
		header("Location: product.php");
	}
}

?>