<?php

session_start();

include "joindatabase.php";

$delproductname = $_POST['productdelbasket'];
$delpid;
$dpcost;
$sql_delbasket = "SELECT * FROM product  WHERE name = '$delproductname'";
$resultdelbasket = mysqli_query($db, $sql_delbasket);
while ($row = mysqli_fetch_assoc($resultdelbasket)){
	$delpid = $row['pid'];
	$dpcost = $row['price'];
}

$isFound = false;
$firstLoop = true;
$pid_arraylist = explode(',', $_SESSION['pidlist']);

for ($i = 0; $i < sizeof($pid_arraylist); $i = $i + 1)
{
	$cur_pid = $pid_arraylist[$i];
	$cur_pid_str = (string) $cur_pid;

	if ($cur_pid != $delpid || $isFound)
	{
		if ($firstLoop == true)
		{
			$newlist = $cur_pid_str;
			$firstLoop = false;
		}
		else
		{
			$newlist = $newlist . "," . $cur_pid_str;
		}
	}
	else
	{
		$isFound = true;
	}
}

if ($isFound == true)
{
	$_SESSION['pidlist'] = $newlist;
	$bid = $_SESSION['bid'];
	$sql_insertquery = "UPDATE basket SET pid_list = '$newlist', total_price = total_price - '$dpcost' WHERE bid = '$bid'";
	$result = mysqli_query($db,$sql_insertquery);
}
else
{
	$_SESSION['productnotfound'] = 1;
}
header("Location: basket.php");
?>