<?php

include "joindatabase.php";

session_start();
if(isset($_POST['newpname'])){

$newpname2 = $_POST['newpname'];
$newprice2 = $_POST['newprice'];

$pid89;
$sql_findpid = "SELECT MAX(pid) AS myMax1 FROM product";
$resul_findpid = mysqli_query($db, $sql_findpid);

while ($cicikus = mysqli_fetch_assoc($resul_findpid))
{
	$pid89 = $cicikus['myMax1'];
}
$pid89 = $pid89 + 1;

if ((strlen($newpname2) == 0) && (strlen($newprice2) == 0))
{
	$_SESSION['productempty3435'] = 1;
	header("Location: product.php");
}
else
{
	if ((strlen($newpname2) >= 0) && (strlen($newpname2) < 6))
	{
		$_SESSION['pnamewrong2'] = 1;
	}
	if (strlen($newprice2) > 0)
	{
		$myString2 = $newprice2;
		$myArray2 = str_split($myString2);
		$pnamecheck = true;
 
		foreach($myArray2 as $character)
		{
    		if ( !("0" <= $character && "9" >= $character))
    		{
        		$pnamecheck = false;
    		}
		}
		if ($pnamecheck == false)
		{
			$_SESSION['pricewrong2'] = 1;
		}
	}
	else
	{
		$_SESSION['pricewrong2'] = 1;
	}

	if (isset($_SESSION['pnamewrong2']) || isset($_SESSION['pricewrong2']))
	{
		header("Location: product.php");
	}
	else
	{
		$sql_changepname38 = "INSERT INTO product (pid, name, price) VALUES ('$pid89', '$newpname2', '$newprice2')";
		$result_changepname38 = mysqli_query($db,$sql_changepname38);
		header("Location: product.php");
		$_SESSION['padded'] = 1;
	}
}


}
?>