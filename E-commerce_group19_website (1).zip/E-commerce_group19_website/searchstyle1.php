<?php
session_start();
if (isset ($_SESSION['searchstyle']))
{
	if ($_SESSION['searchstyle'] == 1)
	{
		$_SESSION['searchstyle'] = 4;
	}
	else
	{
		$_SESSION['searchstyle'] = 1;
	}
}
else
{
	$_SESSION['searchstyle'] = 1;
}
header("Location: searchproducts.php")

?>