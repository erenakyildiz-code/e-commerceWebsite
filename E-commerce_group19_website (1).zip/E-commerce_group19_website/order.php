<?php
session_start();
include "joindatabase.php";
$address;
$oid89 ;
$basketid = $_SESSION['bid'];
$sql_findoid = "SELECT MAX(oid) AS myMax2 FROM order_";
$resul_findoid = mysqli_query($db, $sql_findoid);

while ($muz = mysqli_fetch_assoc($resul_findoid))
{
  $oid89 = $muz['myMax2'];
}
$oid89 = $oid89 + 1;
if(isset($_POST['Address']) ){
  $Deposit = 0;
  $address = $_POST['Address'];

  if(strlen($address) == 0){
    
    $_SESSION['addresswrongo'] = 1;


  }
  $cardido = $_POST['Card_id'];
  if(strlen($cardido) != 16){
    
    $_SESSION['cardwrongo'] = 1;

  }
  else{
    $myStringo = $cardido;
    $myArrayo = str_split($myStringo);
    $numChecko = true;
 
    foreach($myArrayo as $charactero){
        if ( !("0" <= $charactero && "9" >= $charactero)){
            $numChecko = false;
        }
    }
  
    if ($numChecko == false)
    {
      
      $_SESSION['cardwrongo'] = 1;
    }
  }
}
else{
  if(isset($_POST['Deposit_amount'])){
    if(strlen($_POST['Deposit_amount']) == 0){
      $Deposit = 0;

    }
    else{
      $Deposit = $_POST['Deposit_amount'];
      $myStringo = $Deposit;
      $myArrayo = str_split($myStringo);
      $numChecko = true;
 
      foreach($myArrayo as $charactero){
          if ( !("0" <= $charactero && "9" >= $charactero)){
              $numChecko = false;
          }
      }
      if ($numChecko == false)
      {
      $_SESSION['deposit_wrong'] = 1;
      }
      else{
        $sql_query9 = "SELECT * FROM basket WHERE bid = $basketid";
        $result9 = mysqli_query($db, $sql_query9);
        $maxamount;
          while ($row = mysqli_fetch_assoc($result9)){
            $maxamount = $row['total_price'];
          }
          $Depositint = intval($Deposit);
          $maxamountint = intval($maxamount);
        if(($Depositint) >= ($maxamountint/2)){
          $_SESSION['deposit_alot'] = 1;
        }
      }

    }


  }
  $user_id = $_SESSION['uid'];
  $slq_findadress = "SELECT address FROM user_ WHERE uid = $user_id";
  $result_address = mysqli_query($db,$slq_findadress);
  while ($muzeyyen = mysqli_fetch_assoc($result_address))
  {
    $address = $muzeyyen['address'];
  }
}
$continue = true;
if(isset($_SESSION['deposit_wrong'])||isset($_SESSION['cardwrongo'])||isset($_SESSION['addresswrongo'])|| isset($_SESSION['deposit_alot']))
{
  header('Location: orderproccess.php');
  $continue = false;
}
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);
.btn { display: inline-block; *display: inline; *zoom: 1; padding: 4px 10px 4px; margin-bottom: 0; font-size: 13px; line-height: 18px; color: #333333; text-align: center;text-shadow: 0 1px 1px rgba(255, 255, 255, 0.75); vertical-align: middle; background-color: #f5f5f5; background-image: -moz-linear-gradient(top, #ffffff, #e6e6e6); background-image: -ms-linear-gradient(top, #ffffff, #e6e6e6); background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#ffffff), to(#e6e6e6)); background-image: -webkit-linear-gradient(top, #ffffff, #e6e6e6); background-image: -o-linear-gradient(top, #ffffff, #e6e6e6); background-image: linear-gradient(top, #ffffff, #e6e6e6); background-repeat: repeat-x; filter: progid:dximagetransform.microsoft.gradient(startColorstr=#ffffff, endColorstr=#e6e6e6, GradientType=0); border-color: #e6e6e6 #e6e6e6 #e6e6e6; border-color: rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.1) rgba(0, 0, 0, 0.25); border: 1px solid #e6e6e6; -webkit-border-radius: 4px; -moz-border-radius: 4px; border-radius: 4px; -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05); -moz-box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05); box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.05); cursor: pointer; *margin-left: .3em; }
.btn:hover, .btn:active, .btn.active, .btn.disabled, .btn[disabled] { background-color: #e6e6e6; }
.btn-large { padding: 9px 14px; font-size: 15px; line-height: normal; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; }
.btn:hover { color: #333333; text-decoration: none; background-color: #e6e6e6; background-position: 0 -15px; -webkit-transition: background-position 0.1s linear; -moz-transition: background-position 0.1s linear; -ms-transition: background-position 0.1s linear; -o-transition: background-position 0.1s linear; transition: background-position 0.1s linear; }
.btn-primary, .btn-primary:hover { text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.25); color: #ffffff; }
.btn-primary.active { color: rgba(255, 255, 255, 0.75); }
.btn-primary { background-color: #4a77d4; background-image: -moz-linear-gradient(top, #6eb6de, #4a77d4); background-image: -ms-linear-gradient(top, #6eb6de, #4a77d4); background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#6eb6de), to(#4a77d4)); background-image: -webkit-linear-gradient(top, #6eb6de, #4a77d4); background-image: -o-linear-gradient(top, #6eb6de, #4a77d4); background-image: linear-gradient(top, #6eb6de, #4a77d4); background-repeat: repeat-x; filter: progid:dximagetransform.microsoft.gradient(startColorstr=#6eb6de, endColorstr=#4a77d4, GradientType=0);  border: 1px solid #3762bc; text-shadow: 1px 1px 1px rgba(0,0,0,0.4); box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 1px 2px rgba(0, 0, 0, 0.5); }
.btn-primary:hover, .btn-primary:active, .btn-primary.active, .btn-primary.disabled, .btn-primary[disabled] { filter: none; background-color: #4a77d4; }
.btn-block { width: 100%; display:block; }
* { -webkit-box-sizing:border-box; -moz-box-sizing:border-box; -ms-box-sizing:border-box; -o-box-sizing:border-box; box-sizing:border-box; }
html { width: 100%; height:100%; overflow:hidden; }
body {
  width: 100%;
  height:100%;
  font-family: 'Open Sans', sans-serif;
  background: #092756;
  background: -moz-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%),-moz-linear-gradient(top,  rgba(57,173,219,.25) 0%, rgba(42,60,87,.4) 100%), -moz-linear-gradient(-45deg,  #670d10 0%, #092756 100%);
  background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -webkit-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -webkit-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
  background: -o-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -o-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -o-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
  background: -ms-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), -ms-linear-gradient(top,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), -ms-linear-gradient(-45deg,  #670d10 0%,#092756 100%);
  background: -webkit-radial-gradient(0% 100%, ellipse cover, rgba(104,128,138,.4) 10%,rgba(138,114,76,0) 40%), linear-gradient(to bottom,  rgba(57,173,219,.25) 0%,rgba(42,60,87,.4) 100%), linear-gradient(135deg,  #670d10 0%,#092756 100%);
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3E1D6D', endColorstr='#092756',GradientType=1 );
}
.login {
  position: absolute;
  top: 50%;
  left: 50%;
  margin: -150px 0 0 -150px;
  width:300px;
  height:300px;
}
.login h1 { color: #fff; text-shadow: 0 0 10px rgba(0,0,0,0.3); letter-spacing:1px; text-align:center; }
input {
  width: 100%;
  margin-bottom: 10px;
  background: rgba(0,0,0,0.3);
  border: none;
  outline: none;
  padding: 10px;
  font-size: 13px;
  color: #fff;
  text-shadow: 1px 1px 1px rgba(0,0,0,0.3);
  border: 1px solid rgba(0,0,0,0.3);
  border-radius: 4px;
  box-shadow: inset 0 -5px 45px rgba(100,100,100,0.2), 0 1px 1px rgba(255,255,255,0.2);
  -webkit-transition: box-shadow .5s ease;
  -moz-transition: box-shadow .5s ease;
  -o-transition: box-shadow .5s ease;
  -ms-transition: box-shadow .5s ease;
  transition: box-shadow .5s ease;
}
.my-button {
    display: inline-block;
    margin: 7px; /* space between buttons */
    background: #58ACFA; /* background color */
    color: #FFFFFF;/* text color */
    font-size: 1.0 em;
    font-family: ‘Georgia’;
    border-radius: 50px; /* rounded corners */
    padding: 8px 16px; /* space around text */
    -moz-transition: all 0.2s;
    -webkit-transition: all 0.2s;
    transition: all 0.2s;
}
.my-button:hover {
    background: #666;
    color: #c1e1e0;
}
input:focus { box-shadow: inset 0 -5px 45px rgba(100,100,100,0.4), 0 1px 1px rgba(255,255,255,0.2); }
/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}
button:hover {
  opacity: 0.8;
}
/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}
img.avatar {
  width: 40%;
  border-radius: 50%;
}
.container {
  padding: 16px;
}
span.psw {
  float: right;
  padding-top: 16px;
}
/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}
/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}
/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}
.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}
/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}
@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)}
  to {-webkit-transform: scale(1)}
}
@keyframes animatezoom {
  from {transform: scale(0)}
  to {transform: scale(1)}
}
/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
</html>
<?php
if ($continue == true)
{
  $date = "";
  if(($Deposit != 0)){
	 $d=strtotime("+1 Months");
	 $date =date("Y-m-d", $d) . "<br>";
  }
  $sql_addorder = "INSERT INTO order_  VALUES ('$oid89','invoice.jpg', 'Preparing' ,'$date', '$address', '$Deposit', '$basketid')";
  $result_addorder = mysqli_query($db,$sql_addorder);

  if ($_SESSION['role'] == "cust")
  {
  	$slq_findoidlist = "SELECT oid_list FROM customer WHERE uid = $user_id";
  	$result_findoidlist = mysqli_query($db,$slq_findoidlist);
  	$listfound = false;
  	$oid_list;
  	while ($lokum = mysqli_fetch_assoc($result_findoidlist))
  	{
  		$oid_list = $lokum['oid_list'];
  	}

  	if (strlen($oid_list) != 0)
  	{
  		$oid_list = $oid_list . "," . $oid89;
  		$sql_updateoid = "UPDATE customer SET oid_list = '$oid_list' WHERE uid = $user_id";
  		$result_updateoid = mysqli_query($db,$sql_updateoid);
  	}
  	else
  	{
  		$oid_list = $oid89;
  		$sql_updateoid = "UPDATE customer SET oid_list = '$oid_list' WHERE uid = $user_id";
  		$result_updateoid = mysqli_query($db,$sql_updateoid);
  	}
}
unset($_SESSION['bid']);
unset($_SESSION['pidlist']);
}

echo '<div align="left"><form action="profilepage.php" method = "POST"><button type="submit" class="btn btn-primary btn-block btn-large"style="height:35px;width:100px">My Profile</button></form>';


if ($_SESSION['role'] == "vis")
{
	echo '<form action="mainpage.php" method = "POST"><button type="submit" class="btn btn-primary btn-block btn-large"style="height:35px;width:100px"> Go back</button></form>';
}
else if ($_SESSION['role'] == "pman")
{
	echo '<form action="productmanagermain.php" method = "POST"><button type="submit" class="btn btn-primary btn-block btn-large"style="height:35px;width:100px"> Go back</button></form>';
}
else if ($_SESSION['role'] == "sman")
{
	echo '<form action="salesmanagermain.php" method = "POST"><button type="submit" class="btn btn-primary btn-block btn-large"style="height:35px;width:100px"> Go back</button></form>';
}
else if ($_SESSION['role'] == "cust")
{
	echo '<form action="customermain.php" method = "POST"><button type="submit" class="btn btn-primary btn-block btn-large"style="height:35px;width:100px"> Go back</button></form>';
}
?>
<br>
<br>
<div align="center">
<h1 style="color:#F78181;">Your order was successfully placed! :) See profile for status.<h1>
<br>
<br>
<br>
</div>