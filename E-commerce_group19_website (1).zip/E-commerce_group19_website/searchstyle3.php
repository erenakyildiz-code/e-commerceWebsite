<?php
session_start();
if (isset ($_SESSION['searchstyle']))
{
	if ($_SESSION['searchstyle'] == 3)
	{
		$_SESSION['searchstyle'] = 6;
	}
	else
	{
		$_SESSION['searchstyle'] = 3;
	}
}
else
{
	$_SESSION['searchstyle'] = 3;
}
header("Location: searchproducts.php")

?>