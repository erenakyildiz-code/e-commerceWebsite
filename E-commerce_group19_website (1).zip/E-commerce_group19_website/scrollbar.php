<head>
<style>
body {
  overflow-y: scroll; /* Show vertical scrollbar /
  overflow-x: scroll; / Show horizontal scrollbar */
}
</style>
</head>