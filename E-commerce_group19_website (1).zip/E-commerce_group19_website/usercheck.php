<?php
session_start();
include "joindatabase.php";
$id = 1;
if ( isset ($_POST['name'])){
	$id = 0;
	$username = $_POST['name'];
	$password = $_POST['pass'];
	$sql_query = "SELECT uid ,username , password_ FROM user_ ";
	$result = mysqli_query($db, $sql_query);
	while ($row = mysqli_fetch_assoc($result)){
		if (($username == $row['username']) && ($password == $row['password_'])){
				$id = $row['uid'];
				$_SESSION['uid'] = $id;
				

				$sql_productmanager_query ="SELECT uid FROM user_ WHERE uid IN (SELECT uid FROM product_manager WHERE uid = $id)";
				$result_productmanager = mysqli_query($db, $sql_productmanager_query);
				while ($row1 = mysqli_fetch_assoc($result_productmanager)){
					$_SESSION['role'] = "pman";
					header ("Location: productmanagermain.php");



				}

				$sql_salesmanager_query = "SELECT uid FROM user_ WHERE uid IN (SELECT uid FROM sales_manager WHERE uid = $id)";
				$result_salesmanager = mysqli_query($db, $sql_salesmanager_query);
				while ($row2 = mysqli_fetch_assoc($result_salesmanager)){
					$_SESSION['role'] = "sman";
					header ("Location: salesmanagermain.php");


				}



				$sql_customer_query = "SELECT uid FROM user_ WHERE uid IN (SELECT uid FROM customer WHERE uid = $id)";
				$result_customer = mysqli_query($db, $sql_customer_query);
				while ($row3 = mysqli_fetch_assoc($result_customer)){
					$_SESSION['role'] = "cust";
					header ("Location: customermain.php");


				}


		}
	}
}

else{


header("Location: index.php");

}

if($id == 0){
	session_start();
	$_SESSION['error_login'] = 1;
	header("Location: index.php");
	
}

?>