<?php

session_start();

include "joindatabase.php";

$cur_pid = $_SESSION['pid'];
$overall_r;

$sql_query_overall_r = "SELECT * FROM product WHERE pid = $cur_pid";
$result_overall_r = mysqli_query($db, $sql_query_overall_r);
while ($row = mysqli_fetch_assoc($result_overall_r)){
	$overall_r = $row['overall_rating'];
}

$newrating = $_POST['newrating'];

$cur_uid = $_SESSION['uid'];
$date = "dummydate";

$date = date('Y-m-d', time());

$sql_insertrating = "INSERT INTO rate (uid, pid, date, rating) VALUES ('$cur_uid' ,  '$cur_pid' , '$date', '$newrating')";
$result_insertrating = mysqli_query($db,$sql_insertrating);

if ($result_insertrating == 0)
{
	$_SESSION['alreadyrated'] = 1;
}

$new_overall_r;
$sql_query_avg_rate = "SELECT AVG(rating) AS myAvg FROM rate WHERE pid = $cur_pid";
$result_avg_rate = mysqli_query($db, $sql_query_avg_rate);
while ($row = mysqli_fetch_assoc($result_avg_rate)){
	$new_overall_r = $row['myAvg'];
}

$sql_insertquery_new_overall = "UPDATE product SET overall_rating = '$new_overall_r' WHERE pid = '$cur_pid'";
$result_new_overall = mysqli_query($db,$sql_insertquery_new_overall);


header("Location: productpage.php");

?>