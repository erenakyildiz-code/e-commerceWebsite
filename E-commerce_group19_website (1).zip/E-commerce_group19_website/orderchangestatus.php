<?php

include "joindatabase.php";
session_start();

$status = $_POST['status'];
$orderlist = $_SESSION['oidlist'];
$oid_arraylist = explode(',', $orderlist);
$deloid = $_SESSION['cur_oid'];
$checked_uid = $_SESSION['checked_uid'];

if ($status == "Delete")
{
	$isFound = false;
	$firstLoop = true;
	for ($i = 0; $i < sizeof($oid_arraylist); $i = $i + 1)
	{
		$cur_oid = $oid_arraylist[$i];
		$cur_oid_str = (string) $cur_oid;

		if ($cur_oid != $deloid || $isFound)
		{
			if ($firstLoop == true)
			{
				$newlist = $cur_oid_str;
				$firstLoop = false;
			}
			else
			{
				$newlist = $newlist . "," . $cur_oid_str;
			}
		}
		else
		{
			$isFound = true;
		}
	}

	$sql_insertquery = "UPDATE customer SET oid_list = '$newlist' WHERE uid = '$checked_uid'";
	$result = mysqli_query($db,$sql_insertquery);

	$sql_delorder = "DELETE FROM order_ WHERE oid = '$deloid'";
	$result_delorder = mysqli_query($db, $sql_delorder);
}
else
{
	$sql_insertquery = "UPDATE order_ SET status = '$status' WHERE oid = '$deloid'";
	$result = mysqli_query($db,$sql_insertquery);
}

$_SESSION['successchangeorder'] = 1;

header("Location: ordermanage.php");

?>