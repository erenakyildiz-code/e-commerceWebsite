<?php
include "joindatabase.php";
session_start();

$pname = $_SESSION['pname'];
$sql_query8 = "SELECT * FROM product  WHERE name = '$pname'";
$result8 = mysqli_query($db, $sql_query8);
while ($row = mysqli_fetch_assoc($result8)){
	$pid = $row['pid'];
	$pcost = $row['price'];
	$_SESSION['pid'] = $pid;
	$pidstring = (string) $pid;
}

if (isset($_SESSION['pidlist'])){
	$_SESSION['pidlist'] = $_SESSION['pidlist'] . "," . $pidstring;
	$dummy = $_SESSION['pidlist'];
	$bid = $_SESSION['bid'];
	$sql_insertquery = "UPDATE basket SET pid_list = '$dummy', total_price = total_price + '$pcost' WHERE bid = '$bid'";         
	$result = mysqli_query($db,$sql_insertquery);
}
else{
	$sql_insertquery = "SELECT MAX(bid) AS myMax FROM basket";
	$result = mysqli_query($db,$sql_insertquery);
	while ($row = mysqli_fetch_assoc($result)){
		$bid = $row['myMax'];
	}
	$bid = $bid + 1;
	$_SESSION['bid'] = $bid;
	$_SESSION['pidlist'] = $pidstring;
	$dummy2 = $_SESSION['pidlist'];
	$sql_insertquery = "INSERT INTO basket VALUES ('$bid', '$pcost', '$dummy2')";
	$result = mysqli_query($db,$sql_insertquery);
}

header("Location: basket.php");

?>