<?php
session_start();
include "joindatabase.php";

if ( isset ($_POST['password'])){
	
	$password = $_POST['password'];

	if(strlen($password) > 0 && strlen($password) < 8) {
		
		$_SESSION['passwordwrong'] = 1;
	}
	$adress = $_POST['Address'];
	$phone_num = $_POST['phonenum'];
	if(strlen($phone_num) != 11 && strlen($phone_num) != 0){
		
		$_SESSION['phonewrong'] = 1;

	}
	else if (strlen($phone_num) == 11){
		$myString = $phone_num;
		$myArray = str_split($myString);
		$numCheck = true;
 
		foreach($myArray as $character){
    		if ( !("0" <= $character && "9" >= $character)){
        		$numCheck = false;
    		}
		}
	
		if ($numCheck == false)
		{
			
			$_SESSION['phonewrong'] = 1;
		}
	}
	if((strlen($password)) == 0 && (strlen($adress)== 0) &&(strlen($phone_num)== 0)){
		$_SESSION['nochange'] = 1;

	}
	if(isset($_SESSION['passwordwrong'])  || isset($_SESSION['phonewrong']) || isset($_SESSION['nochange'])){
		header("Location: changeinfo.php");
		

		
	}
	else{
		$uid = $_SESSION['uid'];
		
		echo $uid;
		if(strlen($password) != 0){
			$sql_insertquery = "UPDATE user_ SET password_ = '$password' WHERE uid = '$uid'";
			$result = mysqli_query($db,$sql_insertquery);
			
		}
		if(strlen($adress)!= 0){
			$sql_insertquery2 = "UPDATE user_ SET address = '$adress' WHERE uid = '$uid'";
			$result = mysqli_query($db,$sql_insertquery2);
		}
		if(strlen($phone_num)!= 0){
			$sql_insertquery3 = "UPDATE user_ SET phone_num = '$phone_num' WHERE uid = '$uid'";
			$result = mysqli_query($db,$sql_insertquery3);

		}
		header("Location: profilepage.php");
		$_SESSION["confirmed_change"] = 1;

		

	}

}







?>